package pe.edu.cibertec.estudianteapp.data.model

data class Estudiante (
    val estudiante: String,
    val contraseña: String
        )