package pe.edu.cibertec.estudianteapp.data.model

data class Curso (
    val idCurso: Int,
    val title: String,
    val content: String
    )