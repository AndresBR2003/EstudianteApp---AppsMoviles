package pe.edu.cibertec.estudianteapp.data.model

data class Sedes(
    val idSede: Int,
    val nombre: String,
    val imagen: String,
    val ubicacionUrl: String
)